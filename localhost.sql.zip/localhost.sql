-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 13, 2023 at 10:56 PM
-- Server version: 4.1.22
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `bike_house`
--
CREATE DATABASE `bike_house` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bike_house`;

-- --------------------------------------------------------

--
-- Table structure for table `accessory`
--

CREATE TABLE IF NOT EXISTS `accessory` (
  `idAcc` int(11) NOT NULL auto_increment,
  `img` varchar(200) NOT NULL default '',
  `Nom` varchar(255) default NULL,
  `Type` varchar(100) default NULL,
  `prix` float default NULL,
  `detail` text,
  `annee` int(11) default NULL,
  `quantite` int(11) default NULL,
  `marque` varchar(255) default NULL,
  `stock` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`idAcc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `accessory`
--

INSERT INTO `accessory` (`idAcc`, `img`, `Nom`, `Type`, `prix`, `detail`, `annee`, `quantite`, `marque`, `stock`) VALUES
(1, '../../Img/Helmet.jpg', 'Helmet', 'Safety Gear', 99.99, 'Full-face helmet for motorcycle riders', 2023, 29, 'KYT americans', 'In Stock'),
(2, '../../Img/Gloves.jpg', 'Gloves', 'Safety Gear', 29.99, 'Motorcycle riding gloves', 2023, 49, 'KEMIMOTO', 'In Stock'),
(3, '../../Img/Backpack.jpg', 'Backpack', 'Luggage', 79.999, 'Waterproof backpack for bikers', 2023, 13, 'RevZilla', 'In Stock'),
(4, '../../Img/Jacket.jpg', 'Jacket', 'Safety Gear', 1000, 'A Jacket for Motorcycle Riding Safety Gear', 2019, 0, 'FOX', 'Out of Stock'),
(5, '../../Img/Saddle.jpg', 'Saddle', 'Luggage', 200, 'Niche 2pcs Motorcycle Saddle Bag Panniers', 2020, 3, 'Niche', 'In Stock');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`) VALUES
(8);

-- --------------------------------------------------------

--
-- Table structure for table `bike`
--

CREATE TABLE IF NOT EXISTS `bike` (
  `idBike` int(11) NOT NULL auto_increment,
  `img` varchar(250) NOT NULL default '',
  `Nom` varchar(255) default NULL,
  `Type` varchar(100) default NULL,
  `prix` float default NULL,
  `detail` text,
  `annee` int(11) default NULL,
  `taille` int(11) default NULL,
  `stock` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`idBike`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `bike`
--

INSERT INTO `bike` (`idBike`, `img`, `Nom`, `Type`, `prix`, `detail`, `annee`, `taille`, `stock`) VALUES
(1, '../../Img/s1000rr.jpg', 's1000rr', 'Sport Bike', 18000, 'Powerful sport bike with advanced features', 2023, 180, 'In Stock'),
(3, '../../Img/YZF-R1.jpg', 'YZF-R1', 'Sport Bike', 22000, 'High-performance racing bike with cutting-edge technology', 2023, 178, 'Out of Stock'),
(6, '../../Img/H2R.jpg', 'H2R', 'Sport Bike', 8000, 'The Kawasaki Ninja H2®R is the world\\\\\\\\', 2022, 208, 'Out of Stock'),
(8, '../../Img/Hayabusa.jpg', 'Hayabusa', 'Sport Bike', 18799, 'The Suzuki GSX1300R Hayabusa is a sports motorcycle made by Suzuki since 1999.', 2021, 116, 'Out of Stock'),
(9, '../../Img/Husqvarna701.jpg', 'Husqvarna701', 'Dirt Bike', 12999, 'Knowing no boundaries, the versatile 701 Enduro is incredibly proficient within urban environments and truly excels on its favoured offroad terrain.', 2021, 150, 'In Stock'),
(10, '../../Img/Superleggera V4.jpg', 'Superleggera V4', 'Sport Bike', 100000, 'Superleggera V4 is not only our most precious production motorbike, it is a totalizing experience that brings you inside Ducati.', 2021, 148, 'In Stock'),
(11, '../../Img/CBR1000RR-R.jpg', 'CBR1000RR-R', 'Sport Bike', 28900, 'Light and compact 998cc engine was developed with an eye to various global racings including world superbike championship.', 2022, 150, 'In Stock');

-- --------------------------------------------------------

--
-- Table structure for table `buyacc`
--

CREATE TABLE IF NOT EXISTS `buyacc` (
  `idAcc` int(11) default NULL,
  `id` int(11) default NULL,
  `quantite` int(11) NOT NULL default '0',
  KEY `idAcc` (`idAcc`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyacc`
--

INSERT INTO `buyacc` (`idAcc`, `id`, `quantite`) VALUES
(4, 1, 10),
(1, 1, 1),
(5, 1, 10),
(1, 10, 18),
(4, 1, 20),
(3, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `buybike`
--

CREATE TABLE IF NOT EXISTS `buybike` (
  `idBike` int(11) default NULL,
  `id` int(11) default NULL,
  KEY `idBike` (`idBike`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buybike`
--

INSERT INTO `buybike` (`idBike`, `id`) VALUES
(10, 1),
(6, 1),
(8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL default '0',
  `solde` float NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `solde`) VALUES
(1, 818000),
(2, 20019),
(3, 9041),
(4, 30000),
(5, 19000.1),
(6, 32000),
(7, 0),
(9, 99270),
(10, 7189.18),
(11, 0),
(12, 0),
(13, 0),
(14, 100000),
(15, 0),
(16, 0),
(17, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `id` int(11) NOT NULL auto_increment,
  `Nom` varchar(255) default NULL,
  `Prenom` varchar(255) default NULL,
  `mail` varchar(255) default NULL,
  `Telephone` varchar(8) default NULL,
  `Adresse` varchar(200) default NULL,
  `passwordX` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id`, `Nom`, `Prenom`, `mail`, `Telephone`, `Adresse`, `passwordX`) VALUES
(2, 'Doe', 'Jane', 'jane@example.com', '21474836', '456 Elm St', '0011'),
(3, 'Johnson', 'Michael', 'michael@example.com', '21474836', '789 Oak Ave', '1100'),
(5, 'hamza', 'blili', 'hamza@gmail.com', '90303560', '12 rus aa', '5566'),
(6, 'youssef', 'werfelli', 'youssefwerfelli@gmail.com', '21897753', '12 rus aa', '328311'),
(8, 'Admin', 'xxxx', 'Admin@gmail.com', '00000000', 'admin', 'admin0000'),
(9, 'test', 'ing', 'test@gmail.com', '99999999', 'test', 'test'),
(14, 'badis', 'ptiswis', 'badis@gmail.com', '25417186', 'hamamet', '5555');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buyacc`
--
ALTER TABLE `buyacc`
  ADD CONSTRAINT `buyacc_ibfk_3` FOREIGN KEY (`idAcc`) REFERENCES `accessory` (`idAcc`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `buyacc_ibfk_4` FOREIGN KEY (`id`) REFERENCES `client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `buybike`
--
ALTER TABLE `buybike`
  ADD CONSTRAINT `buybike_ibfk_3` FOREIGN KEY (`idBike`) REFERENCES `bike` (`idBike`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `buybike_ibfk_4` FOREIGN KEY (`id`) REFERENCES `client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
